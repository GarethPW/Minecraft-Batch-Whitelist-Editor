﻿Note: You must have Python 2.x installed in order to use this software.

You may distribute and edit this code as you please, provided that credit is given.