'''
    edit.py for Python 2.7 by Gareth Welch (www.garethpw.net)
    You may distribute and edit this code as you please, provided that credit is given.

    Appends to or creates a whitelist.json file based on a list of usernames.
    
    wl  -> whitelist
    wlf -> whitelist file
    np  -> new players (file)
    fp  -> failed players
    fpf -> failed players file
'''

import json,urllib2,codecs
from time import sleep

fp = []

print "Loading whitelist.json..."

def make_wl():
    with codecs.open("whitelist.json",'w',encoding="utf-8-sig") as wlf:
            wlf.write("[]") #Create empty whitelist.json if the file does not exist
            wlf.close()

while True:
    try:
        with codecs.open("whitelist.json",'r',encoding="utf-8-sig") as wlf:
            wl = json.loads(wlf.read()) #Decode whitelist.json file
            wlf.close()
            break
    except IOError:
        print "\nwhitelist.json does not exist; creating..."
        make_wl()
    except ValueError:
        print "\nwhitelist.json is corrupted or badly formatted; recreating..."
        make_wl()
            
print "\nDone!"
sleep(0.5)

print "\nLoading UUIDs of new players and appending to whitelist...\n"

with codecs.open("new_players.txt",'r',encoding="utf-8-sig") as np:
    for l in np: #For each new player,
        print l.replace("\r\n",'')
        try:
            wl.append({'uuid':json.loads(urllib2.urlopen("https://api.mojang.com/users/profiles/minecraft/"+l.lower()).read())['id'],
                       'name':l.replace("\r\n",'')}) #Send request to Mojang API for UUID, then append name and UUID to whitelist
        except ValueError:
            fp.append(l.replace("\r\n",''))
            print "* Failed!"
        except urllib2.HTTPError:
            print "* HTTP Error; retrying..."
            for i in range(5):
                try:
                    sleep(2)
                    wl.append({'uuid':json.loads(urllib2.urlopen("https://api.mojang.com/users/profiles/minecraft/"+l.lower()).read())['id'],
                               'name':l.replace("\r\n",'')}) #Send request to Mojang API for UUID, then append name and UUID to whitelist
                    print "* Success!"
                    break
                except ValueError:
                    fp.append(l.replace("\r\n",''))
                    print "* Failed!"
                    break
                except urllib2.HTTPError:
                    if i == 4:
                        print "* Tried five times with no luck; marking as failed."
    np.close()
with codecs.open("whitelist.json",'w',encoding="utf-8-sig") as wlf:
    wlf.write(json.dumps(wl,indent=4,separators=(',', ': '))) #Save file with indents to make it look fancy
    wlf.close()
with codecs.open("failed_players.txt",'w',encoding="utf-8-sig") as fpf:
    for i in fp:
        fpf.write(i+'\r\n') #Write failed players to failed_players.txt
    fpf.close()

print "\nDone with "+str(len(fp))+" failures."
sleep(0.5)
